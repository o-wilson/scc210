#!/bin/bash
#Run the fullthrottle.FullThrottle class

java -cp out:lib/jsfml.jar fullthrottle.FullThrottle